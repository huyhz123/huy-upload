<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RoleAndPermissionSeeder::class,
            UserSeeder::class,
            ServiceSeeder::class,
            ProductSeeder::class,
            FileSeeder::class,
            CourseSeeder::class,
            SettingSeeder::class,
        ]);
    }
}
